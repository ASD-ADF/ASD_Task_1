#ifndef ASD_TASK_1_H_INCLUDED
#define ASD_TASK_1_H_INCLUDED

void view_arr(int arr[]);
void exercise_1();
void exercise_2(int n, int p);
void exercise_3(int s1, int s2, int s3);
void exercise_4();
int exercise_5(int arr[],int f);
void exercise_6(int arr[],int x);

#endif // ASD_TASK_1_H_INCLUDED
